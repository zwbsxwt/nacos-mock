nohup java \
-Dmockserver.persistExpectations=true \
-Dmockserver.persistedExpectationsPath=mockserverInitialization.json \
-Dmockserver.initializationJsonPath=mockserverInitialization.json \
-jar ./mockserver-netty-5.14.0-shaded.jar -serverPort 1080 -logLevel INFO &
